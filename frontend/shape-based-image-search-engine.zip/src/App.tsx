/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import Navbar from "./components/Navbar";
import Home from "./pages/Home";

export default function App() {
  return (
    <div id="shape-search-root-container" className="min-h-screen bg-[#FAFAFA] text-gray-850">
      <Navbar />
      <Home />
    </div>
  );
}
