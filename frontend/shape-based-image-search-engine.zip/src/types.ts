export interface SearchResult {
  id: number;
  title: string;
  score: number;
  imageUrl: string;
  category: string;
  description: string;
}

export interface SearchFilters {
  category: string;
  minScore: number;
}
