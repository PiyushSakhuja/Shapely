import { SearchResult } from "../types";

// A curated list of high-quality images representing distinct shapes, matching general skeletal silhouettes
const ALL_SHAPES: SearchResult[] = [
  {
    id: 1,
    title: "Minimalist Heart Stone",
    score: 0.98,
    category: "Heart",
    description: "A perfectly smooth river stone shaped naturally like a heart, resting on sand.",
    imageUrl: "https://images.unsplash.com/photo-1518199266791-5375a83190b7?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: 2,
    title: "Crimson Heart Balloon",
    score: 0.92,
    category: "Heart",
    description: "A single red heart-shaped helium balloon floating against a pristine blue sky.",
    imageUrl: "https://images.unsplash.com/photo-1516589178581-6cd7833ae3b2?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: 3,
    title: "Cumulus Cloud Drift",
    score: 0.95,
    category: "Cloud",
    description: "A solitary fluffy white cumulus cloud floating over deep blue sky.",
    imageUrl: "https://images.unsplash.com/photo-1534088568595-a066f410bcda?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: 4,
    title: "Stormy Cumulonimbus",
    score: 0.86,
    category: "Cloud",
    description: "A dark, dramatic cloud formation resembling an anvil with soft, rounded contours.",
    imageUrl: "https://images.unsplash.com/photo-1504608524841-42fe6f032b4b?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: 5,
    title: "Mount Fuji Peaks",
    score: 0.97,
    category: "Mountain",
    description: "The stunning symmetrical snow-capped volcanic cone of Mount Fuji.",
    imageUrl: "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: 6,
    title: "Patagonian Alpine Needle",
    score: 0.89,
    category: "Mountain",
    description: "Sharp, triangular granite rock peaks rising abruptly into the crisp mountain air.",
    imageUrl: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: 7,
    title: "Desert Saguaro Silhouette",
    score: 0.94,
    category: "Cactus",
    description: "The iconic columnar silhouette of a saguaro cactus stretching towards the sunset.",
    imageUrl: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: 8,
    title: "Modernist Teacup",
    score: 0.91,
    category: "Cup",
    description: "A clean ceramic cup with a bold circular handle, highlighting circular contours.",
    imageUrl: "https://images.unsplash.com/photo-1517256064527-09c53b2d0bc6?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: 9,
    title: "Crescent Moon over Pines",
    score: 0.96,
    category: "Moon",
    description: "A bright crescent moon floating above the dark silhouette of evergreen trees.",
    imageUrl: "https://images.unsplash.com/photo-1507499739999-097706ad8914?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: 10,
    title: "Golden Starfish",
    score: 0.93,
    category: "Star",
    description: "A five-pointed orange starfish sitting gracefully on fine beach sand.",
    imageUrl: "https://images.unsplash.com/photo-1549488344-1f9b8d2bd1f3?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: 11,
    title: "Sunburst Over the Ocean",
    score: 0.94,
    category: "Sun",
    description: "The bright solar sphere casting geometric rays through clouds above calm water.",
    imageUrl: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: 12,
    title: "Forest Fir Silhouette",
    score: 0.92,
    category: "Tree",
    description: "A solitary conical pine tree silhouetted perfectly against a soft sunrise horizon.",
    imageUrl: "https://images.unsplash.com/photo-1502082553048-f009c37129b9?auto=format&fit=crop&w=600&q=80"
  }
];

/**
 * Simulates a contour-matching/shape-matching query from the drawn image.
 * In a real application, the PNG blob would be POSTed to FastAPI for OpenCV matchShapes / contour analysis.
 * Here we analyze pixel coverage to match a candidate shape type, or fallback to a realistic simulated ranking.
 */
export async function searchShapesByImage(
  imageBlob: Blob | null,
  canvasElement: HTMLCanvasElement | null,
  customCategoryRegex?: string
): Promise<SearchResult[]> {
  // Simulate network delay
  await new Promise((resolve) => setTimeout(resolve, 1400));

  if (!imageBlob || !canvasElement) {
    throw new Error("Invalid canvas data provided for shape extraction.");
  }

  // 1. A fun touch of "real" analysis: Look at the actual drawing canvas.
  // We can calculate the black-pixel density! This makes the simulator genuinely responsive to what was drawn!
  let pixelDensity = 0;
  try {
    const ctx = canvasElement.getContext("2d");
    if (ctx) {
      const width = canvasElement.width;
      const height = canvasElement.height;
      const imgData = ctx.getImageData(0, 0, width, height);
      const data = imgData.data;
      
      let darkPixels = 0;
      let totalPixels = width * height;
      
      // Canvas is white background (255,255,255) with black strokes (0,0,0) or semi-dark
      for (let i = 0; i < data.length; i += 4) {
        const r = data[i];
        const g = data[i+1];
        const b = data[i+2];
        const alpha = data[i+3];
        
        // If it's a solid black stroke or has some opacity
        if (alpha > 50 && (r < 180 || g < 180 || b < 180)) {
          darkPixels++;
        }
      }
      pixelDensity = darkPixels / totalPixels;
    }
  } catch (err) {
    console.warn("Could not analyze canvas pixel density (likely tainted canvas or offscreen error), using default simulation", err);
  }

  // 2. Select a predicted primary category based on pixel density or stroke behavior,
  // or allow random organic matching. Let's map pixel density to nice categories so drawing "more" vs "less" changes outcomes!
  // This makes the mock search feels extremely responsive and not just static!
  let probableCategory = "Heart";
  if (pixelDensity === 0) {
    probableCategory = "Cloud";
  } else if (pixelDensity > 0.08) {
    probableCategory = "Mountain"; // heavy drawing -> solid mountain shape
  } else if (pixelDensity > 0.04) {
    probableCategory = "Tree"; // medium-heavy -> pine trees
  } else if (pixelDensity > 0.02) {
    probableCategory = "Sun"; // concentric star bursts
  } else if (pixelDensity > 0.01) {
    probableCategory = "Heart"; // light contours -> hearts/moons
  } else {
    probableCategory = "Moon";
  }

  // If a custom filter is explicitly specified or if we generate results, we sort of align them
  // Let's shuffle other categories but keep the matching category highest with slightly randomized scores.
  const matchedResults = ALL_SHAPES.map((item) => {
    let baseScore = item.score;
    
    // Boost matching base category to look like a direct hit!
    if (item.category.toLowerCase() === probableCategory.toLowerCase()) {
      baseScore = 0.94 + Math.random() * 0.055; // 0.94 - 0.99
    } else {
      // Slightly randomize non-matching shapes
      baseScore = 0.55 + Math.random() * 0.28; // 0.55 - 0.83
    }
    
    // Ensure boundary
    baseScore = Math.min(0.99, Math.max(0.4, baseScore));
    
    return {
      ...item,
      score: Number(baseScore.toFixed(3))
    };
  });

  // Sort by similarity score descending
  return matchedResults.sort((a, b) => b.score - a.score);
}
