import React, { useRef, useState } from "react";
import DrawingCanvas, { DrawingCanvasRef } from "../../components/DrawingCanvas";
import SearchControls from "../../components/SearchControls";
import ResultsGrid from "../../components/ResultsGrid";
import LoadingOverlay from "../../components/LoadingOverlay";
import EmptyState from "../../components/EmptyState";
import { SearchResult } from "../../types";
import { searchShapesByImage } from "../../services/api";
import { AlertCircle, RotateCcw, Sparkles, Filter } from "lucide-react";

export default function Home() {
  const canvasRef = useRef<DrawingCanvasRef | null>(null);

  // Home Component States
  const [brushSize, setBrushSize] = useState<number>(8);
  const [selectedCategory, setSelectedCategory] = useState<string>("All");
  const [results, setResults] = useState<SearchResult[] | null>(null);
  const [isSearching, setIsSearching] = useState<boolean>(false);
  const [isCanvasEmpty, setIsCanvasEmpty] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Trigger search execution
  const handleSearch = async () => {
    if (!canvasRef.current) return;

    if (canvasRef.current.isCanvasEmpty()) {
      setError("Please draw a shape silhouette on the canvas before searching.");
      return;
    }

    setIsSearching(true);
    setError(null);

    try {
      const blob = await canvasRef.current.getBlob();
      const canvasEl = canvasRef.current.getCanvasElement();
      
      if (!blob || !canvasEl) {
        throw new Error("Could not acquire sketch data from drawing plane.");
      }

      // Execute search on mock API layer (simulates Fourier shape descriptor weights analysis)
      const data = await searchShapesByImage(blob, canvasEl, selectedCategory);
      setResults(data);
    } catch (err: any) {
      setError(err?.message || "FastAPI shape extraction engine is offline. Please try again.");
    } finally {
      setIsSearching(false);
    }
  };

  // Completely reset states
  const handleClearAll = () => {
    if (canvasRef.current) {
      canvasRef.current.clearCanvas();
    }
    setResults(null);
    setIsSearching(false);
    setIsCanvasEmpty(true);
    setError(null);
  };

  // Called when raw stroke count changes on the canvas element
  const handleStrokeChange = () => {
    if (canvasRef.current) {
      setIsCanvasEmpty(canvasRef.current.isCanvasEmpty());
    }
  };

  // Draw one of the sample outlines directly onto canvas element
  const handleSuggestDraw = (shapeType: string) => {
    if (canvasRef.current) {
      canvasRef.current.drawPresetOutline(shapeType);
      setIsCanvasEmpty(false);
      setError(null);
    }
  };

  return (
    <main 
      id="home-page-container" 
      className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 space-y-8"
    >
      
      {/* Introduction Banner header */}
      <div className="flex flex-col gap-2 rounded-2xl bg-amber-50/40 border border-amber-150/40 p-6 sm:p-8">
        <div className="flex items-center gap-2 text-amber-800">
          <Sparkles className="h-5 w-5 animate-pulse" />
          <span className="font-sans font-semibold text-xs uppercase tracking-wider">
            CV-Driven Image Retriever
          </span>
        </div>
        <h1 className="font-sans font-bold text-2xl sm:text-3xl text-gray-900 tracking-tight">
          Shape-Based Silhouette Search Engine
        </h1>
        <p className="font-sans text-xs sm:text-sm text-gray-500 max-w-2xl leading-relaxed">
          Draw a rough freehand outline of common silhouettes below. Our mock OpenCV computer vision engine extracts coordinate moments and Fourier boundary descriptors, matching them immediately against curated image shapes.
        </p>
      </div>

      {/* Grid Layout structure */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Hand: Workspace & Controls Column */}
        <section className="lg:col-span-5 space-y-6">
          <div className="bg-white border border-gray-150 rounded-2xl p-5 shadow-sm space-y-5">
            <h2 className="font-sans font-semibold text-sm text-gray-900 uppercase tracking-wider flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-amber-500"></span>
              Workspace Canvas
            </h2>
            
            <DrawingCanvas
              ref={canvasRef}
              brushSize={brushSize}
              onStrokeChange={handleStrokeChange}
            />
          </div>

          <SearchControls
            onSearch={handleSearch}
            onClearAll={handleClearAll}
            isSearchDisabled={isCanvasEmpty}
            isSearching={isSearching}
            brushSize={brushSize}
            setBrushSize={setBrushSize}
            selectedCategory={selectedCategory}
            setSelectedCategory={setSelectedCategory}
          />
        </section>

        {/* Right Hand: Search Result Panel Column */}
        <section className="lg:col-span-7 bg-white border border-gray-150 rounded-2xl p-6 shadow-sm min-h-[500px] flex flex-col">
          
          {error && (
            <div className="mb-6 flex gap-3 rounded-xl bg-red-50 border border-red-100 p-4 text-sm text-red-700">
              <AlertCircle className="h-5 w-5 text-red-500 shrink-0" />
              <div className="space-y-1">
                <span className="font-medium text-red-850">Processing Error</span>
                <p className="text-xs text-red-650 leading-relaxed">{error}</p>
              </div>
            </div>
          )}

          <div className="flex-1 flex flex-col justify-center">
            {isSearching ? (
              <LoadingOverlay />
            ) : results ? (
              <ResultsGrid results={results} activeCategoryFilter={selectedCategory} />
            ) : (
              <EmptyState onSuggestDraw={handleSuggestDraw} />
            )}
          </div>
        </section>
      </div>
      
    </main>
  );
}
