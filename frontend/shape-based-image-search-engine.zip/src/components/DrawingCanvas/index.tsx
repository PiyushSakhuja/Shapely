import React, { useRef, useState, useEffect, useImperativeHandle, forwardRef } from "react";
import { Undo2, Trash2, Brush, Square, AlertCircle, Sparkles } from "lucide-react";

export interface DrawingCanvasRef {
  getBlob: () => Promise<Blob | null>;
  getCanvasElement: () => HTMLCanvasElement | null;
  clearCanvas: () => void;
  undo: () => void;
  isCanvasEmpty: () => boolean;
  drawPresetOutline: (shapeType: string) => void;
}

interface DrawingCanvasProps {
  brushColor?: string;
  brushSize?: number;
  onStrokeChange?: () => void;
}

const DrawingCanvas = forwardRef<DrawingCanvasRef, DrawingCanvasProps>((props, ref) => {
  const { brushSize = 8, onStrokeChange } = props;

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [history, setHistory] = useState<ImageData[]>([]);
  const [isEmpty, setIsEmpty] = useState(true);

  // Logical resolution of the canvas for consistent outputs (great for FastAPI contour matching)
  const LOGICAL_WIDTH = 600;
  const LOGICAL_HEIGHT = 600;

  // Initialize canvas with white background
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Set pixel density backing
    canvas.width = LOGICAL_WIDTH;
    canvas.height = LOGICAL_HEIGHT;

    // Fill with pristine white background
    ctx.fillStyle = "#FFFFFF";
    ctx.fillRect(0, 0, LOGICAL_WIDTH, LOGICAL_HEIGHT);

    // Initial check
    setIsEmpty(true);
  }, []);

  // Save canvas state to history for undo
  const saveStateToHistory = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    setHistory((prev) => {
      // Limit history size to 25 items to prevent memory overhead
      const nextHistory = [...prev, imgData];
      if (nextHistory.length > 25) {
        nextHistory.shift();
      }
      return nextHistory;
    });
    setIsEmpty(false);
    if (onStrokeChange) {
      onStrokeChange();
    }
  };

  const getCoordinates = (
    e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>
  ): { x: number; y: number } | null => {
    const canvas = canvasRef.current;
    if (!canvas) return null;

    const rect = canvas.getBoundingClientRect();
    let clientX = 0;
    let clientY = 0;

    if ("touches" in e) {
      if (e.touches.length === 0) return null;
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else {
      clientX = e.clientX;
      clientY = e.clientY;
    }

    // Scale accurately since canvas might be stretched responsively
    return {
      x: ((clientX - rect.left) / rect.width) * canvas.width,
      y: ((clientY - rect.top) / rect.height) * canvas.height,
    };
  };

  const startDrawing = (
    e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>
  ) => {
    e.preventDefault();
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const coords = getCoordinates(e);
    if (!coords) return;

    // Save state before starting new stroke
    saveStateToHistory();

    ctx.beginPath();
    ctx.moveTo(coords.x, coords.y);
    ctx.lineTo(coords.x, coords.y); // Draw a dot instantly if clicked

    // Set brush characteristics (black stroke)
    ctx.strokeStyle = "#000000";
    ctx.lineWidth = brushSize;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.stroke();

    setIsDrawing(true);
  };

  const draw = (
    e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>
  ) => {
    if (!isDrawing) return;
    e.preventDefault();

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const coords = getCoordinates(e);
    if (!coords) return;

    ctx.lineTo(coords.x, coords.y);
    ctx.stroke();
  };

  const stopDrawing = (e: React.SyntheticEvent) => {
    if (!isDrawing) return;
    setIsDrawing(false);
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Save state so we can undo a clear!
    saveStateToHistory();

    ctx.fillStyle = "#FFFFFF";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    setIsEmpty(true);
  };

  const undo = () => {
    if (history.length === 0) return;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const prevHistory = [...history];
    const previousState = prevHistory.pop(); // Retrieve the last saved frame
    setHistory(prevHistory);

    if (previousState) {
      ctx.putImageData(previousState, 0, 0);
    }

    // Check if the board is completely empty now
    if (prevHistory.length === 0) {
      // If we popped everything, it's back to original state
      setIsEmpty(true);
    }
  };

  const drawPresetOutline = (shapeType: string) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Save previous state to history so we can undo the preset loaded!
    saveStateToHistory();

    // Clear board first to white background
    ctx.fillStyle = "#FFFFFF";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.beginPath();
    ctx.strokeStyle = "#000000";
    ctx.lineWidth = brushSize;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";

    if (shapeType.toLowerCase() === "heart") {
      ctx.moveTo(300, 180);
      ctx.bezierCurveTo(300, 130, 190, 110, 190, 220);
      ctx.bezierCurveTo(190, 310, 280, 410, 300, 480);
      ctx.bezierCurveTo(320, 410, 410, 310, 410, 220);
      ctx.bezierCurveTo(410, 110, 300, 130, 300, 180);
    } else if (shapeType.toLowerCase() === "cloud") {
      ctx.moveTo(170, 350);
      ctx.quadraticCurveTo(140, 300, 200, 280);
      ctx.quadraticCurveTo(220, 180, 300, 180);
      ctx.quadraticCurveTo(380, 180, 400, 280);
      ctx.quadraticCurveTo(460, 300, 430, 350);
      ctx.quadraticCurveTo(445, 410, 380, 410);
      ctx.quadraticCurveTo(300, 420, 220, 411);
      ctx.quadraticCurveTo(150, 410, 170, 350);
    } else {
      // Mountain
      ctx.moveTo(100, 460);
      ctx.lineTo(250, 180);
      ctx.lineTo(330, 310);
      ctx.lineTo(440, 145);
      ctx.lineTo(520, 460);
      ctx.closePath();
    }
    ctx.stroke();
    setIsEmpty(false);
    if (onStrokeChange) {
      onStrokeChange();
    }
  };

  // Implement the ref interface for exporting the canvas state
  useImperativeHandle(ref, () => ({
    getCanvasElement: () => canvasRef.current,
    clearCanvas,
    undo,
    isCanvasEmpty: () => isEmpty,
    drawPresetOutline,
    getBlob: async (): Promise<Blob | null> => {
      const canvas = canvasRef.current;
      if (!canvas) return null;

      return new Promise<Blob | null>((resolve) => {
        canvas.toBlob((blob) => {
          resolve(blob);
        }, "image/png");
      });
    },
  }));

  return (
    <div className="flex flex-col items-center w-full">
      {/* Interactive drawing stage */}
      <div className="relative w-full aspect-square max-w-[460px] rounded-2xl border border-gray-200 bg-gray-50 p-2 shadow-inner transition-all hover:border-gray-300">
        
        {/* Dynamic Canvas element */}
        <canvas
          id="drawing-canvas-element"
          ref={canvasRef}
          onMouseDown={startDrawing}
          onMouseMove={draw}
          onMouseUp={stopDrawing}
          onMouseLeave={stopDrawing}
          onTouchStart={startDrawing}
          onTouchMove={draw}
          onTouchEnd={stopDrawing}
          className="w-full h-full rounded-xl bg-white cursor-crosshair shadow-sm touch-none"
        />

        {/* Empty Overlay Guidance */}
        {isEmpty && (
          <div className="absolute inset-4 pointer-events-none flex flex-col items-center justify-center text-center bg-white/40 backdrop-blur-[1px] rounded-lg transition-opacity duration-300">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gray-900/10 text-gray-700 mb-2">
              <Brush className="h-5 w-5 animate-bounce" />
            </div>
            <p className="font-sans font-medium text-gray-800 text-sm">Draw here</p>
            <p className="font-sans text-xs text-gray-500 max-w-[180px] mt-1">
              Trace a clean outline of a heart, mountain, or cloud.
            </p>
          </div>
        )}
      </div>

      {/* Auxiliary quick canvas-specific controls */}
      <div className="flex items-center gap-3 mt-4 w-full max-w-[460px] justify-between px-1">
        <div className="flex items-center gap-1.5 text-xs text-gray-400 font-mono">
          <Square className="h-3 w-3 fill-gray-100" />
          <span>{LOGICAL_WIDTH} × {LOGICAL_HEIGHT} PNG Matrix</span>
        </div>

        <div className="flex items-center gap-2">
          {/* Undo Action */}
          <button
            id="btn-canvas-undo"
            onClick={undo}
            disabled={history.length === 0}
            title="Undo last stroke"
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-medium transition-all ${
              history.length === 0
                ? "border-gray-100 bg-gray-50 text-gray-300 cursor-not-allowed"
                : "border-gray-200 bg-white text-gray-600 hover:bg-gray-50 active:scale-95 hover:text-gray-950 hover:border-gray-300"
            }`}
          >
            <Undo2 className="h-3.5 w-3.5" />
            <span>Undo</span>
          </button>

          {/* Clear Action */}
          <button
            id="btn-canvas-clear"
            onClick={clearCanvas}
            disabled={isEmpty}
            title="Clear workspace"
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-medium transition-all ${
              isEmpty
                ? "border-gray-100 bg-gray-50 text-gray-300 cursor-not-allowed"
                : "border-red-100 bg-red-50/50 text-red-650 hover:bg-red-50 hover:text-red-700 active:scale-95"
            }`}
          >
            <Trash2 className="h-3.5 w-3.5" />
            <span>Clear</span>
          </button>
        </div>
      </div>
    </div>
  );
});

DrawingCanvas.displayName = "DrawingCanvas";

export default DrawingCanvas;
