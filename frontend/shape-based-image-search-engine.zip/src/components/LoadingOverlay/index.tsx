import React from "react";
import { motion } from "motion/react";
import { Sparkles, ScanLine } from "lucide-react";

export default function LoadingOverlay() {
  return (
    <div className="flex flex-col items-center justify-center py-16 px-4 text-center rounded-2xl border border-gray-100 bg-white/50 backdrop-blur-sm shadow-sm space-y-5">
      <div className="relative flex items-center justify-center">
        {/* Pulsing ring outer container */}
        <span className="absolute inline-flex h-16 w-16 rounded-full bg-amber-400/10 animate-ping"></span>
        <span className="absolute inline-flex h-20 w-20 rounded-full bg-gray-900/5 animate-pulse"></span>

        {/* Circular main spinner outer ring */}
        <div className="relative h-12 w-12 rounded-full border-4 border-gray-150 border-t-amber-500 animate-spin" />
        
        {/* Centered micro icon */}
        <div className="absolute flex h-6 w-6 items-center justify-center rounded-full bg-white text-gray-900 shadow-sm">
          <Sparkles className="h-3 w-3 text-amber-500" />
        </div>
      </div>

      <div className="space-y-1.5 max-w-sm">
        <h3 className="font-sans font-semibold text-gray-900 text-sm">
          Searching for similar shapes...
        </h3>
        <p className="font-sans text-xs text-gray-500">
          Extracting drawn contour vector bounds & running Fourier moments distance matching algorithms (Mocked API).
        </p>
      </div>

      {/* Scanning representation graphic */}
      <div className="w-56 h-1 bg-gray-100 rounded-full overflow-hidden relative">
        <motion.div
          className="absolute top-0 bottom-0 left-0 w-20 bg-amber-500"
          animate={{ x: ["-100%", "280%"] }}
          transition={{ repeat: Infinity, duration: 1.5, ease: "easeInOut" }}
        />
      </div>
    </div>
  );
}
