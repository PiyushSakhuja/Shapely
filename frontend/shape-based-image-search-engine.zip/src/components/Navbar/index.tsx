import React from "react";
import { Sparkles, Image, HelpCircle, Github } from "lucide-react";

export default function Navbar() {
  return (
    <header 
      id="app-header"
      className="sticky top-0 z-40 w-full border-b border-gray-100 bg-white/80 backdrop-blur-md"
    >
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        {/* Logo and Product Name */}
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gray-900 text-white shadow-sm ring-1 ring-black/5">
            <Sparkles className="h-5 w-5 text-amber-300 animate-pulse" />
          </div>
          <div>
            <span className="font-sans font-semibold tracking-tight text-gray-900 block sm:inline text-base sm:text-lg">
              FormaSeek
            </span>
            <span id="sub-logo" className="ml-1.5 hidden rounded-md bg-gray-100 px-1.5 py-0.5 text-[10px] font-mono font-medium text-gray-600 sm:inline-block">
              Shape Search v1.0
            </span>
          </div>
        </div>

        {/* Navigation & Help Links */}
        <nav className="flex items-center gap-4 sm:gap-6">
          <div className="hidden items-center gap-1.5 text-xs text-gray-500 md:flex">
            <span className="inline-block h-2 w-2 rounded-full bg-emerald-500 animate-ping"></span>
            <span>FastAPI Engine Ready (Mocked)</span>
          </div>
          
          <a
            href="https://github.com"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 text-sm font-medium text-gray-600 hover:text-gray-900 transition-colors"
          >
            <Github className="h-4 w-4" />
            <span className="hidden sm:inline">Source Code</span>
          </a>

          <div className="h-4 w-[1px] bg-gray-200"></div>

          <button
            type="button"
            className="flex items-center gap-1.5 text-sm font-medium text-gray-650 hover:text-gray-900 transition-colors"
            onClick={() => {
              alert(
                "FormaSeek guides contour alignment matching. Draw any bold skeletal silhouette (e.g., heart, star, cloud, mountain) using black ink on the white canvas, then press 'Search' to retrieve matched contours!"
              );
            }}
          >
            <HelpCircle className="h-4 w-4 text-gray-400" />
            <span className="text-gray-600">How to Draw</span>
          </button>
        </nav>
      </div>
    </header>
  );
}
