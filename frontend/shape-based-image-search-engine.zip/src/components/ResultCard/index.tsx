import React from "react";
import { motion } from "motion/react";
import { SearchResult } from "../../types";
import { ShieldAlert, Sparkles, Star } from "lucide-react";

interface ResultCardProps {
  key?: React.Key;
  result: SearchResult;
  rank: number;
}

export default function ResultCard({ result, rank }: ResultCardProps) {
  // Convert similarity score from 0.0-1.0 to percentage string
  const scorePercent = (result.score * 100).toFixed(1);

  // Determine indicator badges/colors based on scores
  const getScoreTheme = (score: number) => {
    if (score >= 0.9) {
      return {
        bg: "bg-emerald-50 text-emerald-700 ring-emerald-600/10",
        bar: "bg-emerald-550",
        message: "High Match"
      };
    }
    if (score >= 0.75) {
      return {
        bg: "bg-amber-50 text-amber-700 ring-amber-600/10",
        bar: "bg-amber-500",
        message: "Partial Match"
      };
    }
    return {
      bg: "bg-gray-50 text-gray-600 ring-gray-600/10",
      bar: "bg-gray-400",
      message: "Rough Shape Match"
    };
  };

  const theme = getScoreTheme(result.score);

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: "easeOut" }}
      whileHover={{ y: -6, transition: { duration: 0.2 } }}
      className="group relative flex flex-col overflow-hidden rounded-2xl border border-gray-150 bg-white shadow-sm transition-all hover:shadow-md hover:border-gray-200"
    >
      {/* Visual Rank Tag */}
      <div className="absolute top-3 left-3 z-10 flex h-6 w-6 items-center justify-center rounded-lg bg-gray-900/85 text-white font-mono text-xs font-bold shadow-md">
        #{rank}
      </div>

      {/* Similarity Score Overlay Tag */}
      <div className="absolute top-3 right-3 z-10">
        <span className={`inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-semibold shadow-md backdrop-blur-sm bg-white/95 ${theme.bg}`}>
          <Sparkles className="h-3 w-3 text-amber-500 animate-spin" style={{ animationDuration: "3s" }} />
          <span>{scorePercent}% Match</span>
        </span>
      </div>

      {/* Primary Image Viewport */}
      <div className="relative aspect-4/3 w-full overflow-hidden bg-gray-50">
        <img
          src={result.imageUrl}
          alt={result.title}
          referrerPolicy="no-referrer"
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        {/* Soft Shadow Gradient on Image */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-transparent pointer-events-none" />
      </div>

      {/* Content Details */}
      <div className="flex flex-1 flex-col p-4">
        <div className="flex items-center gap-1.5">
          <span className="inline-block rounded bg-amber-50 px-1.5 py-0.5 text-[10px] font-mono font-medium text-amber-700 tracking-wider uppercase">
            {result.category}
          </span>
          <span className="text-[10px] text-gray-400">•</span>
          <span className="text-[10px] font-mono text-gray-500">{theme.message}</span>
        </div>

        <h3 className="mt-2 font-sans font-semibold text-sm text-gray-900 leading-tight group-hover:text-amber-700 transition-colors">
          {result.title}
        </h3>

        <p className="mt-1.5 text-xs text-gray-500 leading-normal flex-1">
          {result.description}
        </p>

        {/* Linear Similarity Score Bar indicator */}
        <div className="mt-4 space-y-1">
          <div className="flex items-center justify-between text-[10px] font-mono text-gray-400">
            <span>Symmetry Index (Hu)</span>
            <span>{result.score.toFixed(3)}</span>
          </div>
          <div className="h-1.5 w-full rounded-full bg-gray-100 overflow-hidden">
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: `${result.score * 100}%` }}
              transition={{ duration: 0.8, delay: 0.1, ease: "easeOut" }}
              className={`h-full ${theme.bar}`}
            />
          </div>
        </div>
      </div>
    </motion.div>
  );
}
