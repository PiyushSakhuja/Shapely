import React from "react";
import { Search, RotateCcw, Sliders, ShieldCheck } from "lucide-react";

interface SearchControlsProps {
  onSearch: () => void;
  onClearAll: () => void;
  isSearchDisabled: boolean;
  isSearching: boolean;
  brushSize: number;
  setBrushSize: (size: number) => void;
  selectedCategory: string;
  setSelectedCategory: (cat: string) => void;
}

const CATEGORIES = ["All", "Heart", "Cloud", "Mountain", "Moon", "Sun", "Tree", "Star"];

export default function SearchControls({
  onSearch,
  onClearAll,
  isSearchDisabled,
  isSearching,
  brushSize,
  setBrushSize,
  selectedCategory,
  setSelectedCategory,
}: SearchControlsProps) {
  return (
    <div className="w-full bg-white border border-gray-100 rounded-2xl p-5 shadow-sm space-y-6">
      
      {/* Visual Configuration Details */}
      <div className="space-y-4">
        <div>
          <label className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-gray-500 mb-2">
            <Sliders className="h-3.5 w-3.5" />
            <span>Brush Thickness</span>
          </label>
          <div className="grid grid-cols-4 gap-2">
            {[4, 8, 12, 16].map((size) => (
              <button
                key={size}
                type="button"
                onClick={() => setBrushSize(size)}
                className={`py-2 px-3 rounded-lg border text-xs font-medium flex flex-col items-center justify-center gap-1.5 transition-all ${
                  brushSize === size
                    ? "border-gray-900 bg-gray-900 text-white shadow-sm"
                    : "border-gray-200 bg-white text-gray-600 hover:border-gray-300 hover:bg-gray-50"
                }`}
              >
                <div 
                  className={`rounded-full ${brushSize === size ? "bg-white" : "bg-gray-900"}`} 
                  style={{ width: `${size}px`, height: `${size}px` }}
                />
                <span>{size}px</span>
              </button>
            ))}
          </div>
        </div>

        {/* Bonus: Mock Category Alignment Guide */}
        <div>
          <label className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-gray-500 mb-2">
            <ShieldCheck className="h-3.5 w-3.5 text-gray-450" />
            <span>Contour Align Guide</span>
          </label>
          <div className="flex flex-wrap gap-1.5">
            {CATEGORIES.map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setSelectedCategory(cat)}
                className={`px-2.5 py-1 rounded-md text-xs font-medium transition-all ${
                  selectedCategory === cat
                    ? "bg-amber-100/70 text-amber-800 ring-1 ring-amber-200"
                    : "bg-gray-100 text-gray-600 hover:bg-gray-200/60"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </div>

      <hr className="border-gray-100" />

      {/* Main Execution Buttons */}
      <div className="flex flex-col gap-2.5">
        <button
          id="btn-trigger-search"
          type="button"
          onClick={onSearch}
          disabled={isSearchDisabled || isSearching}
          className={`relative w-full overflow-hidden flex items-center justify-center gap-2.5 py-3.5 px-4 rounded-xl font-sans font-medium text-sm transition-all focus:outline-none focus:ring-2 focus:ring-gray-950/20 active:scale-[0.99] ${
            isSearchDisabled || isSearching
              ? "bg-gray-100 text-gray-400 border border-gray-150 cursor-not-allowed"
              : "bg-gray-900 text-white hover:bg-gray-800 shadow-sm shadow-black/10 hover:shadow-black/20"
          }`}
        >
          <Search className={`h-4 w-4 ${isSearching ? "animate-spin" : ""}`} />
          <span>{isSearching ? "Analysing contours..." : "Search Silhouette Matches"}</span>
        </button>

        <button
          id="btn-trigger-reset"
          type="button"
          onClick={onClearAll}
          className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl border border-gray-200 bg-white hover:bg-gray-50 text-gray-600 hover:text-gray-950 text-sm font-medium transition-all active:scale-[0.99]"
        >
          <RotateCcw className="h-4 w-4 text-gray-450" />
          <span>Reset Canvas & Results</span>
        </button>
      </div>

      <div className="rounded-xl bg-gray-50/50 border border-gray-100 p-3.5 space-y-1">
        <h4 className="text-xs font-semibold text-gray-700">Similarity Tips</h4>
        <p className="text-[11px] text-gray-500 leading-relaxed">
          OpenCV shape-matching matches skeletal edges. Draw strong, single continuous outlines. Avoid filling shapes solidly.
        </p>
      </div>
    </div>
  );
}
