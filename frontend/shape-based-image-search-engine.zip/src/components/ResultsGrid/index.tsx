import React from "react";
import { SearchResult } from "../../types";
import ResultCard from "../ResultCard";

interface ResultsGridProps {
  results: SearchResult[];
  activeCategoryFilter: string;
}

export default function ResultsGrid({ results, activeCategoryFilter }: ResultsGridProps) {
  // Filter client-side if a specific guideline category was clicked (besides "All")
  const filteredResults = results.filter((item) => {
    if (activeCategoryFilter === "All") return true;
    return item.category.toLowerCase() === activeCategoryFilter.toLowerCase();
  });

  return (
    <div className="space-y-5">
      {/* Search Header Statistics */}
      <div className="flex items-center justify-between border-b border-gray-100 pb-4">
        <div>
          <h2 className="font-sans font-semibold text-lg text-gray-900">
            Silhouette Search Results
          </h2>
          <p className="text-xs text-gray-400 mt-0.5">
            Ranked by Hu Moments & Fourier descriptor match rates.
          </p>
        </div>
        <div className="bg-gray-100 px-3 py-1 rounded-full text-xs font-mono font-medium text-gray-600">
          {filteredResults.length} matches found
        </div>
      </div>

      {filteredResults.length === 0 ? (
        <div className="text-center py-12 border border-dashed border-gray-200 rounded-2xl bg-gray-50/50">
          <p className="text-sm text-gray-500 font-medium">No matches in simulated list for category &quot;{activeCategoryFilter}&quot;.</p>
          <p className="text-xs text-gray-450 mt-1">Try drawing another outline or set the filter back to &quot;All&quot;.</p>
        </div>
      ) : (
        <div 
          id="results-grid-layout" 
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {filteredResults.map((result, idx) => (
            <ResultCard key={result.id} result={result} rank={idx + 1} />
          ))}
        </div>
      )}
    </div>
  );
}
