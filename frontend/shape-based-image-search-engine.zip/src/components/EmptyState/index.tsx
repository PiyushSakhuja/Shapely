import React from "react";
import { PenTool, MousePointer, HelpCircle, ArrowUpRight, Cloud, Heart, Mountain } from "lucide-react";

interface EmptyStateProps {
  onSuggestDraw: (shape: string) => void;
}

export default function EmptyState({ onSuggestDraw }: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center py-16 px-6 text-center border-2 border-dashed border-gray-150 rounded-2xl bg-gray-50/50 space-y-6">
      
      {/* Visual illustration containing overlapping shapes */}
      <div className="relative flex items-center justify-center h-20 w-20">
        <div className="absolute -top-1 -left-1 h-12 w-12 rounded-xl bg-amber-50 border border-amber-200/55 flex items-center justify-center text-amber-500 shadow-sm rotate-6">
          <Heart className="h-5 w-5" />
        </div>
        <div className="absolute -bottom-1 -right-1 h-12 w-12 rounded-xl bg-white border border-gray-150 flex items-center justify-center text-gray-500 shadow-sm -rotate-6">
          <Cloud className="h-5 w-5" />
        </div>
        <div className="h-14 w-14 rounded-2xl bg-gray-900 border border-black flex items-center justify-center text-white shadow-md z-10">
          <PenTool className="h-6 w-6 text-amber-300 animate-pulse" />
        </div>
      </div>

      <div className="space-y-1.5 max-w-sm">
        <h3 className="font-sans font-semibold text-gray-900 text-base">
          Draw a shape and start searching.
        </h3>
        <p className="font-sans text-xs text-gray-500 leading-relaxed">
          Use the canvas on the left to sketch any basic silhouette outline. Once drawn, select search to execute contour analysis.
        </p>
      </div>

      {/* Inspirational Suggestions Section */}
      <div className="space-y-2 max-w-xs">
        <span className="text-[10px] font-bold tracking-wider text-gray-400 uppercase">
          Inspiration ideas to draw:
        </span>
        <div className="flex flex-wrap items-center justify-center gap-2">
          {[
            { label: "Heart Shape", shape: "Heart", icon: Heart },
            { label: "Soft Cloud", shape: "Cloud", icon: Cloud },
            { label: "Pointy Peaks", shape: "Mountain", icon: Mountain },
          ].map((item) => (
            <button
              key={item.label}
              type="button"
              onClick={() => onSuggestDraw(item.shape)}
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full border border-gray-200 bg-white hover:border-gray-300 shadow-sm text-xs text-gray-600 hover:text-gray-950 transition-all hover:-translate-y-0.5 active:translate-y-0"
            >
              <item.icon className="h-3 w-3 text-gray-450" />
              <span>{item.label}</span>
              <ArrowUpRight className="h-2.5 w-2.5 text-gray-400" />
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
